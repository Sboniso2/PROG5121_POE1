/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapp;
import java.util.*;
import java.io.*;

public class QuickChatApp {
    static Scanner input = new Scanner(System.in);
    static String storedUsername = "";
    static String storedPassword = "";
    static List<Message> storedMessages = new ArrayList<>();
    static int messageCounter = 0;

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n1. Register\n2. Login\n3. Exit");
            System.out.print("Choose option: ");

            int choice;
            if (input.hasNextInt()) {
                choice = input.nextInt();
                input.nextLine(); // consume newline
            } else {
                System.out.println("Invalid input. Please enter a number.");
                input.nextLine();
                continue;
            }

            switch (choice) {
                case 1:
                    register();
                    break;
                case 2:
                    if (login()) {
                        messagingMenu();
                    }
                    break;
                case 3:
                    System.out.println("Goodbye...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void register() {
        System.out.print("Enter username: ");
        String username = input.nextLine();

        if (username.matches("^(?=.*_).{1,5}$")) {
            System.out.println("Username successfully captured.");
        } else {
            System.out.println("Username is not correctly formatted. It must contain an underscore and be no more than 5 characters.");
            return;
        }

        System.out.print("Enter password: ");
        String password = input.nextLine();

        if (password.matches("^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$")) {
            System.out.println("Password successfully captured.");
        } else {
            System.out.println("Password must be at least 8 characters, include a capital letter, a number, and a special character.");
            return;
        }

        System.out.print("Enter cellphone number (+27XXXXXXXXX): ");
        String cellphone = input.nextLine();

        if (cellphone.matches("\\+27\\d{9}")) {
            System.out.println("Cellphone number successfully captured.");
        } else {
            System.out.println("Cellphone number is not correctly formatted.");
            return;
        }

        storedUsername = username;
        storedPassword = password;
        System.out.println("Registration successful.");
    }

    private static boolean login() {
        if (storedUsername.isEmpty() || storedPassword.isEmpty()) {
            System.out.println("No user registered. Please register first.");
            return false;
        }

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        if (username.equals(storedUsername) && password.equals(storedPassword)) {
            System.out.println("Welcome back, " + username + "!");
            return true;
        } else {
            System.out.println("Login failed. Username or password incorrect.");
            return false;
        }
    }

    private static void messagingMenu() {
        System.out.print("How many messages would you like to send? ");
        int messageCount;

        try {
            messageCount = Integer.parseInt(input.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number.");
            return;
        }

        while (messageCount > 0) {
            System.out.println("\n1. Send Message\n2. View Messages\n3. Exit");
            System.out.print("Choose: ");
            String option = input.nextLine();

            switch (option) {
                case "1":
                    sendMessage();
                    break;
                case "2":
                    displayMessages();
                    break;
                case "3":
                    messageCount = 0;
                    break;
                default:
                    System.out.println("Invalid option.");
            }
            messageCount--;
        }
    }

    private static void sendMessage() {
        System.out.print("Enter recipient's number: ");
        String recipient = input.nextLine();

        System.out.print("Enter message (max 250 characters): ");
        String content = input.nextLine();

        if (content.length() <= 250) {
            Message msg = new Message(++messageCounter, recipient, content);
            storedMessages.add(msg);
            saveToFile(msg);
            System.out.println("Message sent!");
        } else {
            System.out.println("Message too long.");
        }
    }

    private static void displayMessages() {
        if (storedMessages.isEmpty()) {
            loadFromFile();
        }
        for (Message msg : storedMessages) {
            msg.printMessage();
        }
    }

    private static void saveToFile(Message msg) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("messages.txt", true))) {
            writer.write(msg.toFileFormat());
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error saving message.");
        }
    }

    private static void loadFromFile() {
        storedMessages.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader("messages.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Message msg = Message.fromFileFormat(line);
                if (msg != null) {
                    storedMessages.add(msg);
                }
            }
        } catch (IOException e) {
            System.out.println("No saved messages found.");
        }
    }

    static class Message {
        private int messageID;
        private String recipient;
        private String message;
        private String messageHash;

        public Message(int id, String recipient, String message) {
            this.messageID = id;
            this.recipient = recipient;
            this.message = message;
            this.messageHash = createHash();
        }

        private String createHash() {
            return Integer.toHexString((message + messageID).hashCode());
        }

        public void printMessage() {
            System.out.printf("ID: %d | Hash: %s | To: %s | Message: %s\n",
                    messageID, messageHash, recipient, message);
        }

        public String toFileFormat() {
            return messageID + ";" + recipient + ";" + message + ";" + messageHash;
        }

        public static Message fromFileFormat(String line) {
            String[] parts = line.split(";", 4);
            if (parts.length != 4) return null;
            try {
                int id = Integer.parseInt(parts[0]);
                return new Message(id, parts[1], parts[2]);
            } catch (NumberFormatException e) {
                return null;
            }
        }
    }
}

